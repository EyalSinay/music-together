const RapidAPI_KEY = 'b55b07c051msh9077c1a2783dfa9p1cc9d2jsn4bf9a19d92a5';

module.exports = RapidAPI_KEY;
