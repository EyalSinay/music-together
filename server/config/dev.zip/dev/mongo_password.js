const PASSWORD = 'kQqYjbYn6CyT6dQX';
const username = 'CdkbAGwSSWWokzfe';

module.exports = PASSWORD;
